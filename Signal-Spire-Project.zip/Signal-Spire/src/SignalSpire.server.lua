-- Signal Spire: an original, small-scope horror tower prototype.
-- Put this Script in ServerScriptService. Gameplay state and hazard checks stay on the server.

local Players = game:GetService("Players")
local Lighting = game:GetService("Lighting")
local Workspace = game:GetService("Workspace")

local CONFIG = {
    StepsPerSection = 8,
    SectionCount = 4,
    StepRise = 3.5,
    TowerRadius = 9,
    PlatformWidth = 14,
    FirstWaveDelay = 42,
    WaveInterval = 68,
    WarningSeconds = 8,
    WaveSpeed = 9,
}
CONFIG.TotalSteps = CONFIG.StepsPerSection * CONFIG.SectionCount
CONFIG.TopY = 1.5 + CONFIG.TotalSteps * CONFIG.StepRise + 22

local COLORS = {
    Background = Color3.fromRGB(12, 16, 25),
    Platform = Color3.fromRGB(45, 55, 70),
    Signal = Color3.fromRGB(90, 230, 210),
    Warning = Color3.fromRGB(255, 85, 77),
    Gold = Color3.fromRGB(255, 206, 96),
    Text = Color3.fromRGB(243, 246, 250),
}

local SECTION_COLORS = {
    Color3.fromRGB(72, 232, 215),
    Color3.fromRGB(157, 128, 255),
    Color3.fromRGB(255, 190, 92),
    Color3.fromRGB(255, 103, 123),
}

local function accentForStep(step)
    local section = math.clamp(math.ceil(step / CONFIG.StepsPerSection), 1, #SECTION_COLORS)
    return SECTION_COLORS[section]
end

-- Rebuilding the named model makes Studio Play/Stop iteration predictable.
local previousWorld = Workspace:FindFirstChild("SignalSpireWorld")
if previousWorld then
    previousWorld:Destroy()
end

Lighting.ClockTime = 0.4
Lighting.Brightness = 1.6
Lighting.Ambient = Color3.fromRGB(72, 84, 112)
Lighting.OutdoorAmbient = Color3.fromRGB(38, 47, 69)
Lighting.FogColor = Color3.fromRGB(18, 24, 38)
Lighting.FogStart = 100
Lighting.FogEnd = 430

local atmosphere = Lighting:FindFirstChild("SignalSpireAtmosphere") or Instance.new("Atmosphere")
atmosphere.Name = "SignalSpireAtmosphere"
atmosphere.Color = Color3.fromRGB(104, 124, 170)
atmosphere.Decay = Color3.fromRGB(24, 29, 51)
atmosphere.Density = 0.32
atmosphere.Glare = 0.12
atmosphere.Haze = 1.4
atmosphere.Parent = Lighting

local bloom = Lighting:FindFirstChild("SignalSpireBloom") or Instance.new("BloomEffect")
bloom.Name = "SignalSpireBloom"
bloom.Intensity = 0.28
bloom.Size = 28
bloom.Threshold = 1.25
bloom.Parent = Lighting
Players.RespawnTime = 3

local world = Instance.new("Folder")
world.Name = "SignalSpireWorld"
world.Parent = Workspace

local function makePart(name, size, position, color, material, parent)
    local part = Instance.new("Part")
    part.Name = name
    part.Size = size
    part.Position = position
    part.Anchored = true
    part.Color = color
    part.Material = material or Enum.Material.SmoothPlastic
    part.TopSurface = Enum.SurfaceType.Smooth
    part.BottomSurface = Enum.SurfaceType.Smooth
    part.Parent = parent or world
    return part
end

local function addBillboard(adornee, text, color, width)
    local billboard = Instance.new("BillboardGui")
    billboard.Name = "WorldLabel"
    billboard.Adornee = adornee
    billboard.AlwaysOnTop = true
    billboard.Size = UDim2.fromOffset(width or 280, 58)
    billboard.StudsOffset = Vector3.new(0, 5, 0)
    billboard.Parent = adornee

    local label = Instance.new("TextLabel")
    label.BackgroundTransparency = 1
    label.Size = UDim2.fromScale(1, 1)
    label.Font = Enum.Font.GothamBold
    label.Text = text
    label.TextColor3 = color or COLORS.Text
    label.TextScaled = true
    label.TextWrapped = true
    label.TextStrokeTransparency = 0.35
    label.Parent = billboard
    return billboard
end

local function addPointLight(parent, color, brightness, range)
    local light = Instance.new("PointLight")
    light.Color = color
    light.Brightness = brightness or 1.1
    light.Range = range or 16
    light.Shadows = false
    light.Parent = parent
    return light
end

local function makeHudLabel(parent, name, text, position, size, fontSize, color)
    local label = Instance.new("TextLabel")
    label.Name = name
    label.BackgroundTransparency = 1
    label.Position = position
    label.Size = size
    label.Font = Enum.Font.GothamBold
    label.Text = text
    label.TextColor3 = color or COLORS.Text
    label.TextSize = fontSize
    label.TextXAlignment = Enum.TextXAlignment.Left
    label.TextWrapped = true
    label.Parent = parent
    return label
end

local checkpoints = {}
local checkpointPositions = {}
local checkpointByUserId = {}
local visitedStepsByUserId = {}
local highestStepByUserId = {}
local collectedShardsByUserId = {}
local escapedByUserId = {}
local teamCheckpointStage = 0
local goalPosition

local function getPlayerFromHit(hit)
    local character = hit and hit:FindFirstAncestorOfClass("Model")
    if not character then
        return nil
    end
    return Players:GetPlayerFromCharacter(character)
end

local function getStageValue(player)
    local stats = player:FindFirstChild("leaderstats")
    return stats and stats:FindFirstChild("Stage")
end

local function setStatus(player, text, color)
    local playerGui = player:FindFirstChildOfClass("PlayerGui")
    local gui = playerGui and playerGui:FindFirstChild("SignalSpireHUD")
    local panel = gui and gui:FindFirstChild("Panel")
    local status = panel and panel:FindFirstChild("StatusText")
    if status then
        status.Text = text
        status.TextColor3 = color or COLORS.Text
    end
end

local function updateProgress(player)
    local playerGui = player:FindFirstChildOfClass("PlayerGui")
    local gui = playerGui and playerGui:FindFirstChild("SignalSpireHUD")
    local panel = gui and gui:FindFirstChild("Panel")
    local progress = panel and panel:FindFirstChild("ProgressText")
    if not progress then
        return
    end

    local stage = getStageValue(player)
    local highestStep = highestStepByUserId[player.UserId] or 0
    progress.Text = string.format(
        "STEP %02d / %02d     CHECKPOINT %d / %d",
        highestStep,
        CONFIG.TotalSteps,
        math.min(stage and stage.Value or 0, CONFIG.SectionCount - 1),
        CONFIG.SectionCount - 1
    )
end

local function createHud(player)
    local playerGui = player:WaitForChild("PlayerGui", 10)
    if not playerGui then
        return
    end

    local existing = playerGui:FindFirstChild("SignalSpireHUD")
    if existing then
        existing:Destroy()
    end

    local gui = Instance.new("ScreenGui")
    gui.Name = "SignalSpireHUD"
    gui.ResetOnSpawn = false
    gui.IgnoreGuiInset = false
    gui.DisplayOrder = 5
    gui.Parent = playerGui

    local panel = Instance.new("Frame")
    panel.Name = "Panel"
    panel.AnchorPoint = Vector2.new(0.5, 0)
    panel.Position = UDim2.new(0.5, 0, 0, 10)
    panel.Size = UDim2.new(0.92, 0, 0, 112)
    panel.BackgroundColor3 = COLORS.Background
    panel.BackgroundTransparency = 0.12
    panel.BorderSizePixel = 0
    panel.Parent = gui

    local constraint = Instance.new("UISizeConstraint")
    constraint.MinSize = Vector2.new(250, 112)
    constraint.MaxSize = Vector2.new(520, 112)
    constraint.Parent = panel

    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 14)
    corner.Parent = panel

    local stroke = Instance.new("UIStroke")
    stroke.Color = Color3.fromRGB(87, 119, 143)
    stroke.Transparency = 0.35
    stroke.Thickness = 1
    stroke.Parent = panel

    makeHudLabel(panel, "Title", "SIGNAL SPIRE", UDim2.fromOffset(16, 8), UDim2.new(1, -32, 0, 24), 18, COLORS.Signal)
    makeHudLabel(panel, "ProgressText", "STEP 00 / 32     CHECKPOINT 0 / 3", UDim2.fromOffset(16, 34), UDim2.new(1, -32, 0, 20), 13, COLORS.Text)
    makeHudLabel(panel, "StatusText", "Follow the lit ledges. Teal landings are team checkpoints.", UDim2.fromOffset(16, 59), UDim2.new(1, -32, 0, 43), 13, Color3.fromRGB(207, 218, 230))
    updateProgress(player)
end

local function setCheckpointForPlayer(player, stageNumber)
    local position = checkpointPositions[stageNumber]
    if not position then
        return
    end

    checkpointByUserId[player.UserId] = position + Vector3.new(0, 4.5, 0)
    local stageValue = getStageValue(player)
    if stageValue then
        stageValue.Value = math.max(stageValue.Value, stageNumber)
    end
    updateProgress(player)
end

local function unlockTeamCheckpoint(stageNumber)
    if stageNumber <= teamCheckpointStage then
        return
    end

    teamCheckpointStage = stageNumber
    for _, player in ipairs(Players:GetPlayers()) do
        setCheckpointForPlayer(player, stageNumber)
        setStatus(player, string.format("TEAM CHECKPOINT %d ACTIVATED — everyone respawns here.", stageNumber), COLORS.Signal)
    end
end

local function onPlatformTouched(step, hit)
    local player = getPlayerFromHit(hit)
    if not player then
        return
    end

    local userId = player.UserId
    visitedStepsByUserId[userId] = visitedStepsByUserId[userId] or {}
    if not visitedStepsByUserId[userId][step] then
        visitedStepsByUserId[userId][step] = true
        local highest = math.max(highestStepByUserId[userId] or 0, step)
        highestStepByUserId[userId] = highest
        player:SetAttribute("HighestStep", highest)
        updateProgress(player)
    end

    local checkpointStage = step / CONFIG.StepsPerSection
    if step % CONFIG.StepsPerSection == 0 and checkpointStage < CONFIG.SectionCount then
        if checkpointStage > teamCheckpointStage then
            unlockTeamCheckpoint(checkpointStage)
        elseif not checkpointByUserId[userId] and teamCheckpointStage > 0 then
            setCheckpointForPlayer(player, teamCheckpointStage)
        end
    end
end

-- Safe spawn floor and a standard SpawnLocation provide a reliable first spawn.
local spawnFloor = makePart("Safe Start", Vector3.new(34, 2, 34), Vector3.new(0, 0, 0), Color3.fromRGB(27, 39, 55), Enum.Material.Slate)
spawnFloor:SetAttribute("SafeLanding", true)

local spawn = Instance.new("SpawnLocation")
spawn.Name = "Signal Spire Spawn"
spawn.Size = Vector3.new(12, 1, 12)
spawn.Position = Vector3.new(0, 1.5, 0)
spawn.Anchored = true
spawn.Neutral = true
spawn.Duration = 0
spawn.Material = Enum.Material.Neon
spawn.Color = COLORS.Signal
spawn.Parent = world
addPointLight(spawn, COLORS.Signal, 1.5, 28)
addBillboard(spawn, "SIGNAL SPIRE\nClimb together. Watch for the Echo.", COLORS.Text, 330)

-- Tower supports make the climb readable from below without expensive assets.
for _, x in ipairs({ -22, 22 }) do
    for _, z in ipairs({ -22, 22 }) do
        local beam = makePart(
            "Tower Support",
            Vector3.new(1.2, CONFIG.TopY, 1.2),
            Vector3.new(x, CONFIG.TopY / 2 - 2, z),
            Color3.fromRGB(29, 38, 56),
            Enum.Material.Metal
        )
        beam.CanCollide = false
    end
end

local function stepPosition(step)
    local angle = math.rad((step - 1) * (360 / CONFIG.StepsPerSection))
    local y = 1.5 + step * CONFIG.StepRise
    return Vector3.new(math.cos(angle) * CONFIG.TowerRadius, y, math.sin(angle) * CONFIG.TowerRadius)
end

-- Four luminous square truss bands and distant floating rock formations give each climb section a landmark.
for band = 1, CONFIG.SectionCount do
    local y = 1.5 + (band - 1) * CONFIG.StepsPerSection * CONFIG.StepRise + 13
    local accent = SECTION_COLORS[band]
    for segment = 0, 7 do
        local angle = math.rad(segment * 45)
        local position = Vector3.new(math.cos(angle) * 27, y, math.sin(angle) * 27)
        local rib = makePart("Signal Ring Rib", Vector3.new(11, 0.8, 1.2), position, accent, Enum.Material.Metal)
        rib.CFrame = CFrame.new(position) * CFrame.Angles(0, angle + math.pi / 2, 0)
        rib.CanCollide = false
        rib.Transparency = 0.12
    end

    for outcrop = 0, 3 do
        local angle = math.rad(outcrop * 90 + band * 18)
        local position = Vector3.new(math.cos(angle) * 68, y + 8, math.sin(angle) * 68)
        local island = makePart("Floating Ruin", Vector3.new(20, 3, 16), position, Color3.fromRGB(34, 42, 62), Enum.Material.Slate)
        island.CFrame = CFrame.new(position) * CFrame.Angles(0, angle, math.rad((outcrop % 2 == 0) and 4 or -4))
        island.CanCollide = false
        local shardRock = makePart("Ruin Spire", Vector3.new(3, 11, 3), position + Vector3.new(0, 6, 0), accent, Enum.Material.Metal)
        shardRock.CanCollide = false
        shardRock.Transparency = 0.18
    end
end

-- Four spiral sections. Teal platforms are wider, visible, safe landings.
for step = 1, CONFIG.TotalSteps do
    local position = stepPosition(step)
    local isCheckpoint = step % CONFIG.StepsPerSection == 0 and step < CONFIG.TotalSteps
    local accent = accentForStep(step)
    local size = isCheckpoint and Vector3.new(19, 2, 19) or Vector3.new(CONFIG.PlatformWidth, 2, CONFIG.PlatformWidth)
    local platform = makePart(
        isCheckpoint and "Team Checkpoint" or string.format("Ledge %02d", step),
        size,
        position,
        isCheckpoint and Color3.fromRGB(42, 59, 75) or COLORS.Platform,
        Enum.Material.Slate
    )
    platform:SetAttribute("Step", step)
    platform:SetAttribute("SafeLanding", isCheckpoint)
    platform.Touched:Connect(function(hit)
        onPlatformTouched(step, hit)
    end)

    local trim = makePart(
        isCheckpoint and "Checkpoint Signal" or "Ledge Signal",
        Vector3.new(size.X - 1, 0.28, size.Z - 1),
        position + Vector3.new(0, 1.12, 0),
        accent,
        Enum.Material.Neon
    )
    trim.CanCollide = false
    trim.CanTouch = false
    addPointLight(trim, accent, isCheckpoint and 1.5 or 0.65, isCheckpoint and 24 or 12)

    if isCheckpoint then
        local stageNumber = step / CONFIG.StepsPerSection
        checkpoints[#checkpoints + 1] = platform
        checkpointPositions[stageNumber] = position
        addBillboard(platform, string.format("CHECKPOINT %d\nTEAM SAFE ZONE", stageNumber), accent, 300)
    end
end

-- Optional, individually collectable shards. They are not needed to complete the tower.
for shardIndex, step in ipairs({ 4, 12, 20, 28 }) do
    local position = stepPosition(step) + Vector3.new(0, 4, 0)
    local shard = makePart(string.format("Echo Shard %d", shardIndex), Vector3.new(2.3, 2.3, 2.3), position, COLORS.Gold, Enum.Material.Neon)
    shard.Shape = Enum.PartType.Ball
    shard.CanCollide = false
    shard:SetAttribute("ShardId", shardIndex)
    addPointLight(shard, COLORS.Gold, 1.25, 18)
    addBillboard(shard, "ECHO SHARD", COLORS.Gold, 140)

    shard.Touched:Connect(function(hit)
        local player = getPlayerFromHit(hit)
        if not player then
            return
        end

        local userId = player.UserId
        collectedShardsByUserId[userId] = collectedShardsByUserId[userId] or {}
        if collectedShardsByUserId[userId][shardIndex] then
            return
        end
        collectedShardsByUserId[userId][shardIndex] = true

        local stats = player:FindFirstChild("leaderstats")
        local shardCount = stats and stats:FindFirstChild("Shards")
        if shardCount then
            shardCount.Value += 1
        end
        setStatus(player, "Echo shard collected. These are optional exploration rewards.", COLORS.Gold)
    end)
end

-- Final landing and beacon finish the first playable vertical slice.
local lastPosition = stepPosition(CONFIG.TotalSteps)
goalPosition = lastPosition + Vector3.new(0, 5, 0)
local goalPlatform = makePart("Exit Beacon Landing", Vector3.new(20, 2, 20), goalPosition, Color3.fromRGB(53, 106, 99), Enum.Material.Slate)
goalPlatform:SetAttribute("SafeLanding", true)
addBillboard(goalPlatform, "THE SIGNAL\nReach the beacon to escape", COLORS.Signal, 280)

local portal = makePart("Escape Beacon", Vector3.new(5, 12, 2), goalPosition + Vector3.new(0, 7, 0), COLORS.Signal, Enum.Material.Neon)
portal.CanCollide = false
addPointLight(portal, COLORS.Signal, 3, 42)
local beaconHalo = makePart("Beacon Halo", Vector3.new(12, 1, 1), goalPosition + Vector3.new(0, 15, 0), COLORS.Gold, Enum.Material.Neon)
beaconHalo.CFrame = CFrame.new(beaconHalo.Position) * CFrame.Angles(0, 0, math.rad(90))
beaconHalo.CanCollide = false
portal.Touched:Connect(function(hit)
    local player = getPlayerFromHit(hit)
    if not player or escapedByUserId[player.UserId] then
        return
    end

    escapedByUserId[player.UserId] = true
    local stats = player:FindFirstChild("leaderstats")
    local escapes = stats and stats:FindFirstChild("Escapes")
    local stageValue = getStageValue(player)
    if escapes then
        escapes.Value += 1
    end
    if stageValue then
        stageValue.Value = CONFIG.SectionCount
    end
    updateProgress(player)
    setStatus(player, "YOU ESCAPED THE SPIRE! Stay with your team or replay after respawning.", COLORS.Signal)
end)

local instruction = makePart("Climb Guide", Vector3.new(12, 8, 1), Vector3.new(0, 7, -14), Color3.fromRGB(24, 35, 51), Enum.Material.Slate)
instruction.CanCollide = false
addBillboard(instruction, "HOW TO PLAY\nJump between lit ledges. Teal platforms save the whole team.\nWhen the warning appears, climb above the red Echo.", COLORS.Text, 390)

local function isInsideLanding(rootPart, platform, extraMargin)
    local offset = rootPart.Position - platform.Position
    local margin = extraMargin or 2
    return math.abs(offset.X) <= platform.Size.X / 2 + margin
        and math.abs(offset.Z) <= platform.Size.Z / 2 + margin
        and math.abs(offset.Y) <= 8
end

local function isOnSafeLanding(rootPart)
    if isInsideLanding(rootPart, spawnFloor, 2) then
        return true
    end
    for _, platform in ipairs(checkpoints) do
        if isInsideLanding(rootPart, platform, 2) then
            return true
        end
    end
    if goalPosition and math.abs(rootPart.Position.Y - goalPosition.Y) <= 8 then
        local offset = rootPart.Position - goalPosition
        if math.abs(offset.X) <= 12 and math.abs(offset.Z) <= 12 then
            return true
        end
    end
    return false
end

local function setAllStatus(text, color)
    for _, player in ipairs(Players:GetPlayers()) do
        setStatus(player, text, color)
    end
end

local function runEchoWave()
    setAllStatus(string.format("⚠ THE ECHO WAKES IN %d SECONDS — climb above the red light!", CONFIG.WarningSeconds), COLORS.Warning)
    task.wait(CONFIG.WarningSeconds)

    local wave = makePart("The Echo", Vector3.new(110, 1.3, 110), Vector3.new(0, -4, 0), COLORS.Warning, Enum.Material.Neon)
    wave.Transparency = 0.38
    wave.CanCollide = false
    wave.CanTouch = false
    wave.CastShadow = false
    addBillboard(wave, "THE ECHO IS RISING", COLORS.Warning, 250)

    local warden = Instance.new("Model")
    warden.Name = "Echo Warden"
    warden.Parent = world
    local wardenParts = {}
    local function wardenPart(name, size, offset, color, shape, material)
        local part = makePart(name, size, Vector3.new(0, -4, 0) + offset, color, material or Enum.Material.SmoothPlastic, warden)
        part.Shape = shape or Enum.PartType.Block
        part.CanCollide = false
        part.CanTouch = false
        table.insert(wardenParts, {Part = part, Offset = offset})
        return part
    end

    wardenPart("Warden Shadow", Vector3.new(12, 14, 8), Vector3.new(0, 9, 0), Color3.fromRGB(12, 8, 23), Enum.PartType.Ball)
    wardenPart("Warden Face", Vector3.new(8, 6, 2), Vector3.new(0, 13, -4), Color3.fromRGB(31, 14, 35), Enum.PartType.Block)
    local leftEye = wardenPart("Left Signal Eye", Vector3.new(1.4, 1.4, 0.7), Vector3.new(-2.2, 14, -5.2), COLORS.Warning, Enum.PartType.Ball, Enum.Material.Neon)
    local rightEye = wardenPart("Right Signal Eye", Vector3.new(1.4, 1.4, 0.7), Vector3.new(2.2, 14, -5.2), COLORS.Warning, Enum.PartType.Ball, Enum.Material.Neon)
    addPointLight(leftEye, COLORS.Warning, 2, 20)
    addPointLight(rightEye, COLORS.Warning, 2, 20)
    wardenPart("Warden Mouth", Vector3.new(3.2, 0.55, 0.5), Vector3.new(0, 10.8, -5.25), COLORS.Warning, Enum.PartType.Block, Enum.Material.Neon)
    for spike = 1, 5 do
        local x = (spike - 3) * 2.2
        wardenPart("Warden Crown Spike", Vector3.new(1.3, 4, 1.3), Vector3.new(x, 18, 0), Color3.fromRGB(19, 10, 29), Enum.PartType.Ball)
    end
    addBillboard(wardenParts[1].Part, "THE ECHO", COLORS.Warning, 210)

    local y = -4
    local lastFallCheck = 0
    while y < CONFIG.TopY and wave.Parent do
        wave.Position = Vector3.new(0, y, 0)
        for _, entry in ipairs(wardenParts) do
            entry.Part.Position = Vector3.new(0, y, 0) + entry.Offset
        end
        local now = os.clock()
        if now - lastFallCheck >= 0.25 then
            lastFallCheck = now
            for _, player in ipairs(Players:GetPlayers()) do
                local character = player.Character
                local humanoid = character and character:FindFirstChildOfClass("Humanoid")
                local rootPart = character and character:FindFirstChild("HumanoidRootPart")
                if humanoid and rootPart and humanoid.Health > 0 then
                    if rootPart.Position.Y < y + 1 and not isOnSafeLanding(rootPart) then
                        humanoid.Health = 0
                    elseif rootPart.Position.Y < -25 then
                        humanoid.Health = 0
                    end
                end
            end
        end
        y += CONFIG.WaveSpeed * 0.2
        task.wait(0.2)
    end

    if wave.Parent then
        wave:Destroy()
    end
    if warden.Parent then
        warden:Destroy()
    end
    setAllStatus("The Echo passed. The colored team landings are safe zones.", COLORS.Signal)
end

local function addLeaderstats(player)
    local leaderstats = Instance.new("Folder")
    leaderstats.Name = "leaderstats"
    leaderstats.Parent = player

    for _, name in ipairs({ "Stage", "Shards", "Escapes" }) do
        local value = Instance.new("IntValue")
        value.Name = name
        value.Value = 0
        value.Parent = leaderstats
    end
end

local function onPlayerAdded(player)
    addLeaderstats(player)
    if teamCheckpointStage > 0 then
        setCheckpointForPlayer(player, teamCheckpointStage)
    end

    task.spawn(function()
        createHud(player)
        updateProgress(player)
        setStatus(player, "Follow the lit ledges. Teal platforms are shared team checkpoints.", COLORS.Text)
    end)

    player.CharacterAdded:Connect(function(character)
        task.wait(0.25)
        local target = checkpointByUserId[player.UserId]
        local rootPart = character:FindFirstChild("HumanoidRootPart")
        if target and rootPart then
            rootPart.CFrame = CFrame.new(target)
        end
    end)
end

Players.PlayerAdded:Connect(onPlayerAdded)
Players.PlayerRemoving:Connect(function(player)
    checkpointByUserId[player.UserId] = nil
    visitedStepsByUserId[player.UserId] = nil
    highestStepByUserId[player.UserId] = nil
    collectedShardsByUserId[player.UserId] = nil
    escapedByUserId[player.UserId] = nil
end)

-- Handle quick Studio resets where a player already exists when the Script starts.
for _, player in ipairs(Players:GetPlayers()) do
    if not player:FindFirstChild("leaderstats") then
        onPlayerAdded(player)
    end
end

task.spawn(function()
    task.wait(CONFIG.FirstWaveDelay)
    while true do
        if #Players:GetPlayers() > 0 then
            runEchoWave()
        end
        task.wait(CONFIG.WaveInterval)
    end
end)

print("Signal Spire loaded: spiral tower, shared checkpoints, optional shards, readable Echo warnings.")

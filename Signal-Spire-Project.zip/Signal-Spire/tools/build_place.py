#!/usr/bin/env python3
"""Build a visible Signal Spire edit-mode scene and embed the runtime Luau source."""
from __future__ import annotations

import math
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PLACE_PATH = ROOT / "SignalSpire.rbxlx"
SOURCE_PATH = ROOT / "src" / "SignalSpire.server.lua"
SOURCE = SOURCE_PATH.read_text(encoding="utf-8")

TOTAL_STEPS = 32
STEPS_PER_SECTION = 8
STEP_RISE = 3.5
TOWER_RADIUS = 9
TOP_Y = 1.5 + TOTAL_STEPS * STEP_RISE + 22
SECTION_COLORS = [
    (72, 232, 215),
    (157, 128, 255),
    (255, 190, 92),
    (255, 103, 123),
]


def ref(name: str, index: int) -> str:
    return f"RBXSignalSpire{name}{index:04d}"


def color3(r: int, g: int, b: int) -> int:
    return (255 << 24) | (r << 16) | (g << 8) | b


def add_value(parent: ET.Element, tag: str, name: str, value: object) -> ET.Element:
    node = parent.find(f"{tag}[@name='{name}']")
    if node is None:
        node = ET.SubElement(parent, tag, {"name": name})
    node.text = str(value)
    return node


def add_vector(parent: ET.Element, tag: str, name: str, xyz: tuple[float, float, float]) -> None:
    node = ET.SubElement(parent, tag, {"name": name})
    for key, value in zip(("X", "Y", "Z"), xyz):
        child = ET.SubElement(node, key)
        child.text = f"{value:.6f}".rstrip("0").rstrip(".") or "0"


def add_part(parent: ET.Element, name: str, size: tuple[float, float, float], pos: tuple[float, float, float], rgb: tuple[int, int, int], material: int = 272, shape: int = 1, transparency: float = 0, collide: bool = True, rotation: float = 0) -> ET.Element:
    index = add_part.counter
    add_part.counter += 1
    item = ET.SubElement(parent, "Item", {"class": "Part", "referent": ref("Part", index)})
    props = ET.SubElement(item, "Properties")
    add_value(props, "bool", "Anchored", "true")
    add_value(props, "bool", "CanCollide", str(collide).lower())
    add_value(props, "bool", "CanTouch", "false")
    frame = ET.SubElement(props, "CoordinateFrame", {"name": "CFrame"})
    c, s = math.cos(rotation), math.sin(rotation)
    components = (pos[0], pos[1], pos[2], c, 0, s, 0, 1, 0, -s, 0, c)
    for key, value in zip(("X", "Y", "Z", "R00", "R01", "R02", "R10", "R11", "R12", "R20", "R21", "R22"), components):
        ET.SubElement(frame, key).text = f"{value:.8f}".rstrip("0").rstrip(".") or "0"
    add_value(props, "Color3uint8", "Color", color3(*rgb))
    add_value(props, "token", "Material", material)
    add_value(props, "string", "Name", name)
    add_value(props, "token", "TopSurface", 0)
    add_value(props, "token", "BottomSurface", 0)
    add_value(props, "float", "Transparency", transparency)
    add_value(props, "token", "shape", shape)
    add_vector(props, "Vector3", "size", size)
    return item


add_part.counter = 0


def add_lighting(root: ET.Element) -> None:
    item = ET.SubElement(root, "Item", {"class": "Lighting", "referent": "RBXLighting"})
    props = ET.SubElement(item, "Properties")
    add_value(props, "string", "Name", "Lighting")
    add_value(props, "float", "Brightness", "1.6")
    add_value(props, "float", "ClockTime", "0.4")
    add_value(props, "Color3uint8", "Ambient", color3(72, 84, 112))
    add_value(props, "Color3uint8", "OutdoorAmbient", color3(38, 47, 69))
    add_value(props, "Color3uint8", "FogColor", color3(18, 24, 38))
    add_value(props, "float", "FogStart", "100")
    add_value(props, "float", "FogEnd", "430")

    for class_name, name in (("Atmosphere", "SignalSpireAtmosphere"), ("BloomEffect", "SignalSpireBloom")):
        effect = ET.SubElement(item, "Item", {"class": class_name, "referent": f"RBX{name}"})
        effect_props = ET.SubElement(effect, "Properties")
        add_value(effect_props, "string", "Name", name)
        if class_name == "Atmosphere":
            add_value(effect_props, "Color3uint8", "Color", color3(104, 124, 170))
            add_value(effect_props, "Color3uint8", "Decay", color3(24, 29, 51))
            add_value(effect_props, "float", "Density", "0.32")
            add_value(effect_props, "float", "Glare", "0.12")
            add_value(effect_props, "float", "Haze", "1.4")
        else:
            add_value(effect_props, "float", "Intensity", "0.28")
            add_value(effect_props, "float", "Size", "28")
            add_value(effect_props, "float", "Threshold", "1.25")


def build_visible_world(workspace: ET.Element) -> None:
    folder = ET.SubElement(workspace, "Item", {"class": "Folder", "referent": "RBXSignalSpireEditWorld"})
    props = ET.SubElement(folder, "Properties")
    add_value(props, "string", "Name", "SignalSpireWorld")

    add_part(folder, "Safe Start", (34, 2, 34), (0, 0, 0), (27, 39, 55), material=512)
    add_part(folder, "Signal Spire Spawn", (12, 1, 12), (0, 1.5, 0), SECTION_COLORS[0], material=288)

    for x in (-22, 22):
        for z in (-22, 22):
            add_part(folder, "Tower Support", (1.2, TOP_Y, 1.2), (x, TOP_Y / 2 - 2, z), (29, 38, 56), material=1088, collide=False)

    for band, accent in enumerate(SECTION_COLORS, 1):
        y = 1.5 + (band - 1) * STEPS_PER_SECTION * STEP_RISE + 13
        for segment in range(8):
            angle = math.radians(segment * 45)
            pos = (math.cos(angle) * 27, y, math.sin(angle) * 27)
            add_part(folder, "Signal Ring Rib", (11, 0.8, 1.2), pos, accent, material=1088, collide=False, rotation=angle + math.pi / 2)

        for outcrop in range(4):
            angle = math.radians(outcrop * 90 + band * 18)
            pos = (math.cos(angle) * 68, y + 8, math.sin(angle) * 68)
            add_part(folder, "Floating Ruin", (20, 3, 16), pos, (34, 42, 62), material=512, collide=False, rotation=angle)
            add_part(folder, "Ruin Spire", (3, 11, 3), (pos[0], pos[1] + 6, pos[2]), accent, material=1088, collide=False)

    for step in range(1, TOTAL_STEPS + 1):
        angle = math.radians((step - 1) * (360 / STEPS_PER_SECTION))
        y = 1.5 + step * STEP_RISE
        pos = (math.cos(angle) * TOWER_RADIUS, y, math.sin(angle) * TOWER_RADIUS)
        section = min(math.ceil(step / STEPS_PER_SECTION), len(SECTION_COLORS)) - 1
        accent = SECTION_COLORS[section]
        is_checkpoint = step % STEPS_PER_SECTION == 0 and step < TOTAL_STEPS
        dimensions = (19, 2, 19) if is_checkpoint else (14, 2, 14)
        add_part(folder, "Team Checkpoint" if is_checkpoint else f"Ledge {step:02d}", dimensions, pos, (42, 59, 75) if is_checkpoint else (45, 55, 70), material=512)
        add_part(folder, "Checkpoint Signal" if is_checkpoint else "Ledge Signal", (dimensions[0] - 1, 0.28, dimensions[2] - 1), (pos[0], pos[1] + 1.12, pos[2]), accent, material=288, collide=False)

        if step in (4, 12, 20, 28):
            shard_pos = (pos[0], pos[1] + 4, pos[2])
            add_part(folder, f"Echo Shard {step}", (2.3, 2.3, 2.3), shard_pos, (255, 206, 96), material=288, shape=0, collide=False)

    last_angle = math.radians((TOTAL_STEPS - 1) * (360 / STEPS_PER_SECTION))
    goal = (math.cos(last_angle) * TOWER_RADIUS, 1.5 + TOTAL_STEPS * STEP_RISE + 5, math.sin(last_angle) * TOWER_RADIUS)
    add_part(folder, "Exit Beacon Landing", (20, 2, 20), goal, (53, 106, 99), material=512)
    add_part(folder, "Escape Beacon", (5, 12, 2), (goal[0], goal[1] + 7, goal[2]), SECTION_COLORS[0], material=288, collide=False)
    add_part(folder, "Beacon Halo", (12, 1, 1), (goal[0], goal[1] + 15, goal[2]), (255, 206, 96), material=288, collide=False)
    add_part(folder, "Climb Guide", (12, 8, 1), (0, 7, -14), (24, 35, 51), material=512, collide=False)


def main() -> None:
    tree = ET.parse(PLACE_PATH)
    root = tree.getroot()
    workspace = root.find("Item[@class='Workspace']")
    script_service = root.find("Item[@class='ServerScriptService']")
    if workspace is None or script_service is None:
        raise SystemExit("Place file must contain Workspace and ServerScriptService")

    for child in list(root):
        if child.tag == "Item" and child.get("class") == "Lighting":
            root.remove(child)

    for child in list(workspace):
        if child.tag == "Item" and child.get("referent") == "RBXSignalSpireEditWorld":
            workspace.remove(child)
    build_visible_world(workspace)
    add_lighting(root)

    script = script_service.find("Item[@class='Script'][@referent='RBXSignalSpireServer']")
    if script is None:
        script = ET.SubElement(script_service, "Item", {"class": "Script", "referent": "RBXSignalSpireServer"})
        props = ET.SubElement(script, "Properties")
    else:
        props = script.find("Properties")
        if props is None:
            props = ET.SubElement(script, "Properties")
    add_value(props, "string", "Name", "SignalSpireServer")
    add_value(props, "bool", "Disabled", "false")
    protected = props.find("ProtectedString[@name='Source']")
    if protected is None:
        protected = ET.SubElement(props, "ProtectedString", {"name": "Source"})
    protected.text = SOURCE

    ET.indent(tree, space="  ")
    tree.write(PLACE_PATH, encoding="utf-8", xml_declaration=True)
    print(f"Wrote edit-mode world and embedded source to {PLACE_PATH}")


if __name__ == "__main__":
    main()
